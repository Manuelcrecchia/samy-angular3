import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'it.samipulizie.app',
  appName: 'sami',
  webDir: 'dist/y/browser',
};

export default config;
